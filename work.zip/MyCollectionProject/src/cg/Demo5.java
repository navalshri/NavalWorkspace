package cg;
import java.util.*;
import com.cg.bean.*;

import com.cg.service.*;
import java.io.*;
public class Demo5 {

	public static void main(String[] args) throws IOException {
	Map<Long, Account> accmap=new TreeMap<Long, Account>();
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	String choice="";
	while (true)
	{
	System.out.println("Menu");
	System.out.println("======");
	System.out.println("1. create new account ");
	System.out.println("2. print all accounts ");
	System.out.println("3. exit");
	System.out.println("enter your choice");
	choice=br.readLine();
	switch(choice)
	{
	
			
	case "1":
		int id=0;
		long mb=0L;
		String ah="";
		double bal=0.0;
		// accepting and validating for account anumber
		System.out.println("enter account number");
		while(true)

			{
			String s_id=br.readLine();
			boolean ch1=Validator.Validatedata(s_id,Validator.aidpattern);
			if(ch1==true) {
				try {
					id=Integer.parseInt(s_id);
					break;
		}
				catch(NumberFormatException e)
				{
				System.out.println("acc. no must be numeric reenter");	
				}
			}
			else
			{
			System.out.println("reenter account number in 3 digits");	
			}
			}// end of account number while
		// accepting and validating for account anumber
		System.out.println("enter mobile number");
		while(true)

			{
			String s_mb=br.readLine();
			boolean ch1=Validator.Validatedata(s_mb,Validator.mobilepattern);
			if(ch1==true) {
				try {
					mb=Long.parseLong(s_mb);
					break;
		}
				catch(NumberFormatException e)
				{
				System.out.println("mobile no must be numeric reenter");	
				}
			}
			else
			{
			System.out.println("reenter account number in 10 digits");	
			}
			}// end of account number while
		// accepting and validating for account holder
		System.out.println("enter account holder");
		ah=br.readLine();
		//accepting and validating for accoun balance
		System.out.println("enter initial balance");
		String s_bal=br.readLine();
		bal=Double.parseDouble(s_bal);
		
		    Account ob=new Account(id, mb, ah, bal);
		    accmap.put(ob.getMobile(),ob);
		break;
	case "2":
		Collection<Account> vc=accmap.values();
		ArrayList<Account> acclist=new ArrayList<Account>(vc);
		Collections.sort( acclist); 
		for(Account i:acclist)
		{
		System.out.println(i);
		}
		
	break;
	case "3": System.out.println("exiting program");
	System.exit(0);
	
	break;
	 default:
	 System.out.println("invalid choice");
	 
	
	}
	
	}
	}// end of menu

	private static boolean Validatedata(String s_id, String aidpattern) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	/*System.out.println(accmap);
	System.out.println(accmap.keySet());
	Collection<Account> vc=accmap.values();
	ArrayList<Account> acclist=new ArrayList<Account>(vc);
	Collections.sort( acclist); 
	for(Account i:acclist)
	{
	System.out.println(i);
	
	}
	 System.out.println("===============sort by name");
		Comparator nc=new NameComparator();
		Collections.sort(acclist,nc);
		for(Account i:acclist)
		{
			System.out.println(i);
		}
		
		 System.out.println("===============sort by balance");
			Comparator bc=new BalanceComparator();
			Collections.sort(acclist,bc);
			for(Account i:acclist)
			{
				System.out.println(i);
			}*/
	
}
