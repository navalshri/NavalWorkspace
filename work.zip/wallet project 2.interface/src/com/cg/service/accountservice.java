package com.cg.service;

import com.cg.bean.*;
import com.cg.exception.*;
public class accountservice implements gst, transaction {

	@Override
	public double withdraw(Account ob, double amount)throws InsufficientFundException {
		double new_balance=ob.getBalance()-amount;
		if(new_balance<1000.00)
		{ 
			new_balance= ob.getBalance();
		throw new InsufficientFundException("insuu fund cannot proc. withdrawal", new_balance);
			
		}
		ob.setBalance(new_balance);
		return new_balance;
	}

	@Override
	public double deposit(Account ob, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double transfermoney(Account from, Account to, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculatetax(double PCT, double amount) {
		// TODO Auto-generated method stub
		return amount*gst.PCT_5;
	}

}

