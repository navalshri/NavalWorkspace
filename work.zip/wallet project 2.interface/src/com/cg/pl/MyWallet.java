package com.cg.pl;


import com.cg.exception.*;

import com.cg.bean.*;
import com.cg.service.*;
import com.cg.service.gst;
public class MyWallet
{
	public static void main(String[] args)
	{ 
accountservice service=new accountservice();
		
		SavingAccount ob2=new SavingAccount(101,22222222,"raja",55000.00);
		service.printStatement(ob2);// calling default method of transaction
		double b1=0.0;
		try
		{
			b1=service.withdraw(ob2, 55000.00);
			System.out.println("after withdraw balance is"+ b1);
		}
		catch(InsufficientFundException e)
		
		{
			System.err.println(e.getMessage());
			System.err.println(e);
		}
		
		
	
	}	
}
		
