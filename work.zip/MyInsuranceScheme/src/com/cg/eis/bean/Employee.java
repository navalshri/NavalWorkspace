package com.cg.eis.bean;

public class Employee {
	private int e_id;
	private String name;
	private double salary;
	private String designation;
	private String insurance_scheme;
	public Employee(int e_id, String name, double salary, String designation, String insurance_scheme) {
		super();
		this.e_id = e_id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insurance_scheme = insurance_scheme;
	}
	public int getE_id() {
		return e_id;
	}
	public void setE_id(int e_id) {
		this.e_id = e_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsurance_scheme() {
		return insurance_scheme;
	}
	public void setInsurance_scheme(String insurance_scheme) {
		this.insurance_scheme = insurance_scheme;
	}
	@Override
	public String toString() {
		return "Employee [e_id=" + e_id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", insurance_scheme=" + insurance_scheme + "]";
	}
	
	

}
