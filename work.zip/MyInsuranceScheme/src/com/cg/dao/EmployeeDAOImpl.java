package com.cg.dao;

public class EmployeeDAOImpl implements EmployeeDAO {

}
