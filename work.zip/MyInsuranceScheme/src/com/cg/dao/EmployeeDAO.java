package com.cg.dao;

public interface EmployeeDAO {

}
