package com.cg.pl;
import java.io.*;
import java.util.*;
import com.cg.exception.*;
import java.util.*;
import com.cg.bean.*;
import com.cg.service.*;
import javafx.collections.*;
public class MyWallet
{

	public static void main(String[] args) throws IOException, InsufficientFundException
	{
		accountservice service=new accountservice();
	Map<Long, Account> accmap=new TreeMap<Long, Account>();
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	String choice="";
	while (true)
	{
	System.out.println("Menu");
	System.out.println("=======");
	System.out.println("1. create new account ");
	System.out.println("2. print all accounts ");
	System.out.println("3. withdraw  account ");
	System.out.println("4. delete account ");
	System.out.println("5. transfer");
	System.out.println("6. exit");
	System.out.println("enter your choice");
	choice=br.readLine();
	switch(choice)
	{
	
			
	case "1":
		int id=0;
		long mb=0L;
		String ah="";
		double bal=0.0;
		// accepting and validating for account anumber
		System.out.println("enter account number");
		while(true)

			{
			String s_id=br.readLine();
			boolean ch1=Validator.Validatedata(s_id,Validator.aidpattern);
			if(ch1==true) {
				try {
					id=Integer.parseInt(s_id);
					break;
		}
				catch(NumberFormatException e)
				{
				System.out.println("acc. no must be numeric reenter");	
				}
			}
			else
			{
			System.out.println("reenter account number in 3 digits");	
			}
			}// end of account number while
		// accepting and validating for account anumber
		System.out.println("enter mobile number");
		while(true)

			{
			String s_mb=br.readLine();
			boolean ch1=Validator.Validatedata(s_mb,Validator.mobilepattern);
			if(ch1==true) {
				try {
					mb=Long.parseLong(s_mb);
					break;
		}
				catch(NumberFormatException e)
				{
				System.out.println("mobile no must be numeric reenter");	
				}
			}
			else
			{
			System.out.println("reenter account number in 10 digits");	
			}
			}// end of account number while
		// accepting and validating for account holder
		System.out.println("enter account holder");
		while(true)
		{
			String s_ah=br.readLine();
			boolean ch1=Validator.Validatedata(s_ah,Validator.accpattern);
			if(ch1==true) 
			{
				try {
					ah=s_ah;
					break;
		}
				catch(NumberFormatException e)
				{
				System.out.println("name must be string reenter");	
				}
		}
			else
			{
			System.out.println("reenter name");	
			}
		}
		System.out.println("enter initial balance");
			String s_ah=br.readLine();
			 bal=Double.parseDouble(s_ah);
			Account ob=new Account(id,mb,ah,bal);
			accmap.put(ob.getMobile(), ob);
			break;
			
			
	
	   case "2":
		Collection<Account> vc=accmap.values();
		ArrayList<Account> acclist=new ArrayList<Account>(vc);
		
		for(Account i:acclist)
		{
		System.out.println(i);
		}
		
	break;
	case "3":
		System.out.println("enter mobile no.");
	long mnum=Long.parseLong(br.readLine());
		System.out.println("Enter the amount");
		double amount=Double.parseDouble(br.readLine());
		double ans=service.withdraw(accmap.get(mnum), amount);
	break;
	
	
	
	case"4":
		System.out.println("enter mobile no. to delete");
	 mb=Long.parseLong(br.readLine());
	accmap.remove(mb);
	break;
	
	
	case"5": 
		System.out.println("enter from account");
	long from=Long.parseLong(br.readLine());
	 System.out.println("enter to account");
	 long to=Long.parseLong(br.readLine());
	 System.out.println("enter money to transfer");
	 double amount2=Double.parseDouble(br.readLine());
	service.transfermoney(accmap.get(from), accmap.get(to), amount2);
	break; 
	
	
	case"6":System.out.println("exiting program");
	break;
    default:
	 System.out.println("invalid choice");
	 
	
	}
	
	}
	}// end of menu



}













	/*SavingAccount ob2=new SavingAccount(101,22222222,"raja",55000.00);
		service.printStatement(ob2);// calling default method of transaction
		double b1=0.0;
		try
		{
			b1=service.withdraw(ob2, 55000.00);
			System.out.println("after withdraw balance is"+ b1);
		}
		catch(InsufficientFundException e)
		
		{
			System.err.println(e.getMessage());
			System.err.println(e);
		}*/
	
		
	
	
		
