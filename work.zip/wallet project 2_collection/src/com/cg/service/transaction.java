package com.cg.service;
import java.util.*;

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;
public interface transaction extends AccountOperation
{
public double withdraw(Account ob, double amount) throws InsufficientFundException;
public double deposit(Account ob, double amount) throws InsufficientFundException;
public String transfermoney(Account from,Account to,double amount) throws InsufficientFundException;
public default void printStatement(Account ob)
{
	System.out.println("==========================");
	System.out.println("statement for account no" + ob.getAid());

	System.out.println(" account Holder"+ ob.getAccountholder());
	System.out.println("balance is =>"+ ob.getBalance());
	System.out.println("==========================");
}

public boolean addAccount(Account ob);
public boolean deleteAccount(Account ob);

Map<Long,Account> getALLAccounts();
}
