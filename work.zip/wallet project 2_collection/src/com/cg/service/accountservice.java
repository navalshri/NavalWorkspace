package com.cg.service;

import java.util.Map;

import com.cg.bean.*;
import com.cg.dao.AccountDAOImpl;
import com.cg.exception.*;
public class accountservice implements gst, transaction
{
AccountDAOImpl dao=new AccountDAOImpl();
@Override
public double withdraw(Account ob, double amount) throws InsufficientFundException {
	// TODO Auto-generated method stub
double new_balance=ob.getBalance()-amount;
if(new_balance<1000.00)
{
	new_balance=ob.getBalance();
	throw new InsufficientFundException("insuff fund cannot process withdrawal",new_balance);
}
ob.setBalance(new_balance);
return new_balance;
}
@Override
public double deposit(Account ob, double amount) 
{
	double new_balance=ob.getBalance()+amount;
	ob.setBalance(new_balance);
	return new_balance;

}
@Override
public String transfermoney(Account from, Account to, double amount) 
{
	double new_balance=from.getBalance()-amount;
	if(new_balance<1000.00)
	{
		System.out.println("insufficient balnce");
		return "amount cannot be transferred insufficient balance";
	}
	from.setBalance(new_balance);
	double b2=to.getBalance()+amount; 
	to.setBalance(b2);
	
	return "from account: "+ from.getAid()+"Balance: "+from.getBalance()+"\n"+"To account:" +to.getAid()+"Balance"+to.getBalance();
	
	
}
@Override
public double calculatetax(double PCT, double amount) {
	// TODO Auto-generated method stub
	return amount*gst.PCT_5;
	
}
public boolean addAccount(Account ob)
{
	return dao.addAccount(ob);
}
public boolean deleteAccount(Account ob)
{
	return dao.deleteAccount(ob);
}
public boolean findAccount(Long mobileno)
{
	return dao.findAccount(mobileno);
}
public Map<Long, Account> getALLAccounts()
{
	return dao.getALLAccounts();
}

}