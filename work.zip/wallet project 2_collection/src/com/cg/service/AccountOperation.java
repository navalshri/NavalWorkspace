package com.cg.service;
import java.util.*;

import com.cg.bean.Account;

public interface AccountOperation 
{
	public boolean addAccount(Account ob);
	public Map<Long,Account> getALLAccounts();
	public boolean deleteAccount(Account ob);
	public boolean findAccount(Long Account);
}
