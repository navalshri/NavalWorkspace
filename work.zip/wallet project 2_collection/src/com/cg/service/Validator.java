package com.cg.service;

public interface Validator {
    String idpattern="[1-9][0-9][0-9]";
    String deisgnationpattern="[1-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]";
    
   String namepattern="([A-Za-z]{3}[A-Za-z]* [A-Za-z]{3}[A-Za-z]*)|([A-Za-z]+'[A-Za-z]*[A-Za-z]{3}[A-Za-z])";
    
    
    
    public static boolean Validatedata(String data,String pattern) {
		return data.matches(pattern);
		
	}
    
    	
    }

