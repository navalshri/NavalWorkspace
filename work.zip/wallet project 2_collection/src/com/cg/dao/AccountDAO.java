package com.cg.dao;

import java.util.Map;

import com.cg.bean.*;

public interface AccountDAO 
{ 
	public boolean addAccount(Account ob);
	public boolean updateAccount(Account ob);
	public boolean deleteAccount(Account ob);
	public boolean findAccount(Long Account);
	public Map<Long,Account> getALLAccounts();
	public boolean transfermoney(Account from, Account to,double amount);
	
	
	
	
}
