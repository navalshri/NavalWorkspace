package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Account;

public class AccountDAOImpl implements AccountDAO 
{
 Map<Long,Account> accmap= new HashMap<Long,Account>();
public boolean addAccount(Account ob) 
{
	accmap.put(ob.getMobile(), ob);
	return true;
	
}
@Override
public boolean updateAccount(Account ob) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public boolean deleteAccount(Account ob) {
	// TODO Auto-generated method stub
	return true;
}
public boolean transferMoney(Account from,Account to,double amount) {
	// TODO Auto-generated method stub
	return false;
}
public boolean findAccount(long mobileno) {
	// TODO Auto-generated method stub
	Account ob=accmap.get(mobileno);
	return true;
}
@Override
public Map<Long, Account> getALLAccounts() {
	// TODO Auto-generated method stub
	return accmap;
}
@Override
public boolean findAccount(Long Account) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public boolean transfermoney(Account from, Account to, double amount) {
	// TODO Auto-generated method stub
	return false;
}

}


