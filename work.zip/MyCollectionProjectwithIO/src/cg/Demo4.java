package cg;
import java.util.*;
import com.cg.bean.*;
public class Demo4 {

	public static void main(String[] args) {
	Map<Integer, Account> accmap=new TreeMap<Integer, Account>();
	Account ob1= new Account(101,805289573,"Ram",25000.00);
	accmap.put(ob1.getMobile(), ob1);
	Account ob2= new Account(102,983870017,"Shyam",10000.00);
	accmap.put(ob2.getMobile(), ob2);
	Account ob3= new Account(103,958134551,"Abdul",13000.00);
	accmap.put(ob3.getMobile(), ob3);
	Account ob4= new Account(104,958132751,"Ganesh",28000.00);
	accmap.put(ob4.getMobile(), ob4);
	System.out.println(accmap);
	System.out.println(accmap.keySet());
	Collection<Account> vc=accmap.values();
	ArrayList<Account> acclist=new ArrayList<Account>(vc);
	Collections.sort( acclist); 
	for(Account i:acclist)
	{
	System.out.println(i);
	
	}
	 System.out.println("===============sort by name");
		Comparator nc=new NameComparator();
		Collections.sort(acclist,nc);
		for(Account i:acclist)
		{
			System.out.println(i);
		}
		
		 System.out.println("===============sort by balance");
			Comparator bc=new BalanceComparator();
			Collections.sort(acclist,bc);
			for(Account i:acclist)
			{
				System.out.println(i);
			}
	
}
}